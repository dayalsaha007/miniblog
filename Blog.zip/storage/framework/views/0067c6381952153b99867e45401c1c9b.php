<div class="col-lg-4">
    <div class="sidebar">
        <div class="row">
            <div class="col-lg-12">
                <div class="sidebar-item">
                    <?php echo Form::open(['method'=>'get', 'route'=>'Front.search']); ?>

                    <div class="input-group">
                        <?php echo Form::search('search', null, ['class'=>'form-control', 'placeholder'=> 'type to search...']); ?>

                        <?php echo Form::button('Search', ['class'=>'btn btn-success input-group-text', 'type'=>'submit']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            <div class="col-lg-12">
                <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                        <h2>Recent Posts</h2>
                    </div>
                    <div class="content">
                        <ul>
                            <?php $__currentLoopData = $recent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                  <a href="<?php echo e(route('Front.single', $post->slug)); ?>">
                                    <h5><?php echo e($post->title); ?></h5>
                                    <span><?php echo e($post->created_at->format('M D, Y')); ?></span>
                                  </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                        <h2>Categories</h2>
                    </div>
                    <div class="content">
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li><a href="<?php echo e(route('Front.category', $category->slug)); ?>">- <?php echo e($category->name); ?></a>
                            <ul class="sidebar-sub-category">
                                <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('Front.sub_category', [$category->slug, $sub_category->slug])); ?>">- <?php echo e($sub_category->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="sidebar-item tags">
                    <div class="sidebar-heading">
                        <h2>Tag Clouds</h2>
                    </div>
                    <div class="content">
                        <ul>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('Front.tag', $tag->slug)); ?>"><?php echo e($tag->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/frontend/includes/rightsidebar.blade.php ENDPATH**/ ?>