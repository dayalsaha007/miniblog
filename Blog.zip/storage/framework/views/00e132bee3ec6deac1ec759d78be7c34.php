<?php $__env->startSection('Page_title', 'Welcome'); ?>
<?php $__env->startSection('banner'); ?>
    <div class="heading-page header-text">
        <section class="page-heading">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-content">
                            <h4>Post Details</h4>
                            <h2>Single blog post</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="col-lg-12">
        <div class="blog-post">
            <div class="blog-thumb">
                <img src="<?php echo e(url('image/post/Original/'.$post->photo)); ?>" alt="<?php echo e($post->title); ?>">
            </div>
            <div class="down-content">
                <span><?php echo e($post->category?->name); ?> <sub class="text-warning"><?php echo e($post->sub_category?->name); ?></sub></span>
                <a href="<?php echo e(route('Front.single', $post->slug)); ?>">
                    <h4><?php echo e($post->title); ?></h4>
                </a>
                <ul class="post-info">
                    <li><a href="#"><?php echo e($post->user?->name); ?></a></li>
                    <li><a href="#"><?php echo e($post->created_at->format('M d, Y')); ?></a></li>
                    <li><a href="#"><?php echo e($post->comment?->count()); ?> Comments</a></li>
                    <li><a href="#"><?php echo e($post->post_read_count?->count); ?> Viewer</a></li>
                </ul>
                <div class="post_description">
                    <p><?php echo $post->discription; ?></p>
                </div>
                <div class="post-options">
                    <div class="row">
                        <div class="col-6">
                            <ul class="post-tags">
                                <li><i class="fa fa-tags"></i></li>
                                <?php $__currentLoopData = $post->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('Front.tag', $tag->slug)); ?>"><?php echo e($tag->name); ?></a>,</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="post-share">
                                <li><i class="fa fa-share-alt"></i></li>
                                <li><a href="#">Facebook</a>,</li>
                                <li><a href="#"> Twitter</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="sidebar-item comments">
            <div class="sidebar-heading">
                <h2><?php echo e($post->comment?->count()); ?> comments</h2>
            </div>
            <div class="content">
                <ul>
                    <?php $__currentLoopData = $post->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li>
                        <div class="author-thumb">
                            <img src="<?php echo e(asset($path . $post->user->myprofile?->photo)); ?>" alt="<?php echo e(asset('image/user/72547-thinking-photography-question-mark-man-stock.png')); ?>">
                        </div>
                        <div class="right-content">
                            <h4><?php echo e($comment->user?->name); ?><span><?php echo e($comment->created_at->format('M d, Y')); ?></span></h4>
                            <p><?php echo e($comment->comment); ?></p>
                            <h4 class="mt-2">Reply Comment</h4>
                            <?php echo Form::open(['method'=>'post','route'=>'comment.store']); ?>

                            <?php echo Form::text('comment', null, ['class'=>'form-control form-control-sm mt-2', 'placeholder'=>'Write Your Reply Here']); ?>

                            <?php echo Form::hidden('comment_id', $comment->id); ?>

                            <?php echo Form::hidden('post_id', $post->id); ?>

                            <?php echo Form::button('Reply',['class'=>'btn btn-outline-warning mt-2','type'=>'submit']); ?>

                            <?php echo Form::close(); ?>

                            </div>
                        </li>
                        <?php $__currentLoopData = $comment->reply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="replied">
                            <div class="author-thumb">
                                <img src="<?php echo e(asset($path . $reply->user->myprofile?->photo)); ?>" alt="<?php echo e(asset('image/user/72547-thinking-photography-question-mark-man-stock.png')); ?>">
                            </div>
                            <div class="right-content">
                                <h4><?php echo e($reply->user?->name); ?><span><?php echo e($reply->created_at->format('M d, Y')); ?></span></h4>
                                <p><?php echo e($reply->comment); ?></p>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="sidebar-item submit-comment">
            <div class="sidebar-heading">
                <h2>Your comment</h2>
            </div>
            <div class="content">
                <form method="post" action="<?php echo e(route('comment.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                                <input name="post_id" type="hidden" value="<?php echo e($post->id); ?>">
                                <textarea name="comment" rows="6" id="message" placeholder="Type your comment"></textarea>
                                <button type="submit" class="main-button">Submit </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.4.0/axios.min.js" integrity="sha512-uMtXmF28A2Ab/JJO2t/vYhlaa/3ahUOgj1Zf27M5rOo8/+fcTUVH0/E0ll68njmjrLqOBjXM3V9NiPFL5ywWPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>

    const readCount = () => {
        axios.get(window.location.origin+'/post-count/'+<?php echo e($post->id); ?>)
    }

    setTimeout(() => {
        readCount()
    }, 10000);


</script>

<?php $__env->stopPush(); ?>

<?php if(session('msg')): ?>
    <?php $__env->startPush('js'); ?>
        <script>
            $('.delete').on('click', function() {
                let id = $(this).attr('data-id')
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(`#form_${id}`).submit()
                    }
                })
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/frontend/modules/single.blade.php ENDPATH**/ ?>