<?php echo $__env->make('Backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="sb-nav-fixed">
    <?php echo $__env->make('Backend.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav">
        <?php echo $__env->make('Backend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4"><?php echo $__env->yieldContent('page_title'); ?></h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active"><?php echo $__env->yieldContent('page_sub_title'); ?></li>
                    </ol>
                    <?php echo $__env->yieldContent('contant'); ?>
                </div>
            </main>

            <?php echo $__env->make('Backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/layout/master.blade.php ENDPATH**/ ?>