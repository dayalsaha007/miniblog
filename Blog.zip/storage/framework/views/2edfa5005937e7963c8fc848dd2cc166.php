<?php $__env->startSection('Page_title', 'Welcome'); ?>
<?php $__env->startSection('banner'); ?>
 <?php echo $__env->make('frontend.includes.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('single-post'); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-12">
        <div class="blog-post">
            <div class="blog-thumb">
                <img src="<?php echo e(url('image/post/Original/'.$post->photo)); ?>" alt="<?php echo e($post->title); ?>">
            </div>
            <div class="down-content">
                <span><?php echo e($post->category?->name); ?> <sub class="text-warning"><?php echo e($post->sub_category?->name); ?></sub></span>
                <a href="<?php echo e(route('Front.single', $post->slug)); ?>">
                    <h4><?php echo e($post->title); ?></h4>
                </a>
                <ul class="post-info">
                    <li><a href="#"><?php echo e($post->user?->name); ?></a></li>
                    <li><a href="#"><?php echo e($post->created_at->format('M d, Y')); ?></a></li>
                    <li><a href="#"><?php echo e($post->comment?->count()); ?> Comments</a></li>
                    <li><a href="#"><?php echo e($post->post_read_count?->count); ?> Viewer</a></li>
                </ul>
                <div>
                    <p><?php echo Str::limit($post->discription, 500)."......."; ?>

                        <a href="<?php echo e(Route('Front.single', $post->slug)); ?>" class="btn btn-sm btn-warning">Read More</a>
                    </p>

                </div>
                <div class="post-options">
                    <div class="row">
                        <div class="col-6">
                            <ul class="post-tags">
                                <li><i class="fa fa-tags"></i></li>
                                <?php $__currentLoopData = $post->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('Front.tag', $tag->slug)); ?>"><?php echo e($tag->name); ?></a>,</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="post-share">
                                <li><i class="fa fa-share-alt"></i></li>
                                <li><a href="#">Facebook</a>,</li>
                                <li><a href="#"> Twitter</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-12">
        <div class="main-button">
            <a href="<?php echo e(route('Front.all_post')); ?>">View All Posts</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/frontend/modules/index.blade.php ENDPATH**/ ?>