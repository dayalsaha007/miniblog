<?php $__env->startSection('Page_title', 'Contact Us'); ?>
<?php $__env->startSection('banner'); ?>
    <div class="heading-page header-text">
        <section class="page-heading">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-content">
                            <h4>Feel Free To Contact Us</h4>
                            <h2>Contact Us</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4>Contact Us</h4>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php echo Form::open(['method'=>'post','route'=>'contact.store']); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control mt-3', 'placeholder'=>'Write Your Name']); ?>

            <?php echo Form::email('email', null, ['class'=>'form-control mt-3', 'placeholder'=>'Write Your Email']); ?>

            <?php echo Form::text('phone', null, ['class'=>'form-control mt-3', 'placeholder'=>'Write Your Phone Number']); ?>

            <?php echo Form::text('subject', null, ['class'=>'form-control mt-3', 'placeholder'=>'Write Your Subject']); ?>

            <?php echo Form::textarea('massage', null, ['class'=>'form-control mt-3', 'placeholder'=>'Write Your Massage','rows'=>'5']); ?>

            <?php echo Form::button('Send Massage',['class'=>'btn btn-success mt-3','type'=>'submit']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php if(Session('msg')): ?>
    <div class=" alert alert-<?php echo e(session('cls')); ?>">
        <?php echo session('msg'); ?>

    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php if(session('msg')): ?>
    <?php $__env->startPush('js'); ?>
        <script>
            $('.delete').on('click', function() {
                let id = $(this).attr('data-id')
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(`#form_${id}`).submit()
                    }
                })
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/frontend/modules/contact_us.blade.php ENDPATH**/ ?>