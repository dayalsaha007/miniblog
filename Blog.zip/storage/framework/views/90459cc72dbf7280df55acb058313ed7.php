<?php $__env->startSection('page_title', 'Post'); ?>
<?php $__env->startSection('page_sub_title', 'Update'); ?>
<?php $__env->startSection('contant'); ?>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Update Post</h4>
                </div>
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php echo Form::model($post, ['method' => 'PUT', 'route' => ['post.update', $post->id], 'files'=> true]); ?>

                    <?php echo $__env->make('Backend.modules.post.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::button('Update Post', ['type' => 'submit', 'class' => 'btn btn-success mt-2']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <a href="<?php echo e(route('post.index')); ?>" class="btn btn-danger text-light"> Back </a>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            $('#name').on('input', function() {
                let name = $(this).val()
                let slug = name.replaceAll(' ', '-')
                $('#slug').val(slug.toLowerCase());
            })
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/modules/post/edit.blade.php ENDPATH**/ ?>