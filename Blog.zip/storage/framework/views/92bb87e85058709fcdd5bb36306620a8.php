<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
    
    <?php $__env->startSection('page_title', 'Login'); ?>
<?php endif; ?>



<?php echo $__env->make('Backend.Auth.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/Auth/login.blade.php ENDPATH**/ ?>