<?php $__env->startSection('page_title', 'Sub_Category'); ?>
<?php $__env->startSection('page_sub_title', 'List'); ?>
<?php $__env->startSection('contant'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex">
                    <div class="col-6">
                        <h4>Sub_Category List</h4>
                    </div>
                    <div class="col-6 text-end"> <a href="<?php echo e(route('sub_category.create')); ?>"
                            class="btn btn-success btn-sm ">Add
                            Sub_Category</a></div>
                </div>
                <div class="card-body">
                    <?php if(Session('msg')): ?>
                        <div class=" alert alert-<?php echo e(session('cls')); ?>">
                            <?php echo session('msg'); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Slug</th>
                                <th>Status</th>
                                <th>Order By</th>
                                <th>Created At</th>
                                <th>Uploadted At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php  $sl = 1  ?>
                            <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl++); ?></td>
                                    <td><?php echo e($sub_category->name); ?></td>
                                    <td><?php echo e($sub_category->category->name); ?></td>
                                    <td><?php echo e($sub_category->slug); ?></td>
                                    <td><?php echo e($sub_category->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                    <td><?php echo e($sub_category->order_by); ?></td>
                                    <td><?php echo e($sub_category->created_at->toDayDateTimeString()); ?></td>
                                    <td><?php echo e($sub_category->created_at != $sub_category->updated_at ? $sub_category->updated_at->toDayDateTimeString() : 'Not Updated'); ?>

                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="<?php echo e(route('sub_category.show', $sub_category->id)); ?>"><button
                                                    class="btn btn-info btn-sm"><i class="fa-solid fa-eye"></i></button></a>
                                            <a href="<?php echo e(route('sub_category.edit', $sub_category->id)); ?>"><button
                                                    class="btn btn-warning btn-sm mx-1"><i
                                                        class="fa-solid fa-edit"></i></button></a>
                                            <?php echo Form::open([
                                                'method' => 'delete',
                                                'id' => 'form_' . $sub_category->id,
                                                'route' => ['sub_category.destroy', $sub_category->id],
                                            ]); ?>

                                            <?php echo Form::button('<i class="fa-solid fa-trash"></i>', [
                                                'type' => 'button',
                                                'data-id' => $sub_category->id,
                                                'class' => ' delete btn btn-danger btn-sm',
                                            ]); ?>

                                            <?php echo Form::close(); ?>

                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            $('.delete').on('click', function() {
                let id = $(this).attr('data-id')
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(`#form_${id}`).submit()
                    }
                })
            })
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/modules/sub_category/index.blade.php ENDPATH**/ ?>