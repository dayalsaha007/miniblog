<?php $__env->startSection('page_title', 'Sub_Category'); ?>
<?php $__env->startSection('page_sub_title', 'Details'); ?>
<?php $__env->startSection('contant'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Sub_Category Details</h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered table-hover">
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <th><?php echo e($subCategory->id); ?></th>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <td><?php echo e($subCategory->name); ?></td>
                            </tr>
                            <tr>
                                <th>Category</th>
                                <td><?php echo e($subCategory->category->name); ?></td>
                            </tr>
                            <tr>
                                <th>Slug</th>
                                <td><?php echo e($subCategory->slug); ?></td>>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e($subCategory->status == 1 ? 'Active' : 'Inactive'); ?></td>
                            </tr>
                            <tr>
                                <th>Order By</th>
                                <td><?php echo e($subCategory->order_by); ?></td>
                            </tr>
                            <tr>
                                <th>Created At</th>
                                <td><?php echo e($subCategory->created_at->toDayDateTimeString()); ?></td>
                            </tr>
                            <tr>
                                <th>Uploadted At</th>
                                <td><?php echo e($subCategory->created_at != $subCategory->updated_at ? $subCategory->updated_at->toDayDateTimeString() : 'Not Updated'); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('sub_category.index')); ?>" class="btn btn-info btn-sm text-light"> Back </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/modules/sub_category/show.blade.php ENDPATH**/ ?>