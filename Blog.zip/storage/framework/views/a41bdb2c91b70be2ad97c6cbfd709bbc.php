<?php $__env->startSection('Page_title', $title); ?>
<?php $__env->startSection('banner'); ?>
    <div class="heading-page header-text">
        <section class="page-heading">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-content">
                            <h4><?php echo e($sub_title); ?></h4>
                            <h2><?php echo e($title); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-12">
        <div class="blog-post">
            <div class="blog-thumb">
                <img src="<?php echo e(url('image/post/Original/'.$post->photo)); ?>" alt="<?php echo e($post->title); ?>">
            </div>
            <div class="down-content">
                <span><?php echo e($post->category?->name); ?> <sub class="text-warning"><?php echo e($post->sub_category?->name); ?></sub></span>
                <a href="<?php echo e(route('Front.single', $post->slug)); ?>">
                    <h4><?php echo e($post->title); ?></h4>
                </a>
                <ul class="post-info">
                    <li><a href="#"><?php echo e($post->user?->name); ?></a></li>
                    <li><a href="#"><?php echo e($post->created_at->format('M d, Y')); ?></a></li>
                    <li><a href="#"><?php echo e($post->comment?->count()); ?> Comments</a></li>
                </ul>
                <div>
                    <p><?php echo Str::limit($post->discription, 500); ?>

                        <a href="<?php echo e(Route('Front.single', $post->slug)); ?>" class="btn btn-sm btn-warning">Read More</a>
                    </p>
                </div>
                <div class="post-options">
                    <div class="row">
                        <div class="col-6">
                            <ul class="post-tags">
                                <li><i class="fa fa-tags"></i></li>
                                <?php $__currentLoopData = $post->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('Front.tag', $tag->slug)); ?>"><?php echo e($tag->name); ?></a>,</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="post-share">
                                <li><i class="fa fa-share-alt"></i></li>
                                <li><a href="#">Facebook</a>,</li>
                                <li><a href="#"> Twitter</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(count($posts) < 1): ?>
        <h1 class="text-danger">No Post Found</h1>
    <?php endif; ?>

    <div class="col-md-12">
        <?php echo e($posts->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/frontend/modules/all_post.blade.php ENDPATH**/ ?>