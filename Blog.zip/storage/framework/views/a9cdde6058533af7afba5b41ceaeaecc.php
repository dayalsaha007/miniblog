<?php echo Form::label('name', 'Name', ['class' => 'my-2']); ?>

<?php echo Form::text('name', null, [
    'id' => 'name',
    'class' => 'form-control',
    'placeholder' => 'Enter Sub_Category Name',
]); ?>

<?php echo Form::label('slug', 'Slug', ['class' => 'my-2']); ?>

<?php echo Form::text('slug', null, [
    'id' => 'slug',
    'class' => 'form-control ',
    'placeholder' => 'Enter Sub_Category Slug',
]); ?>

<?php echo Form::label('category_id', 'Select Category', ['class' => 'my-2']); ?>

<?php echo Form::select('category_id', $categories, null, [
    'class' => 'form-select ',
    'placeholder' => 'Select Parent Category',
]); ?>

<?php echo Form::label('order_by', 'Sub_Category Serial', ['class' => 'my-2']); ?>

<?php echo Form::number('order_by', null, ['class' => 'form-control ', 'placeholder' => 'Select Sub_Category Serial']); ?>

<?php echo Form::label('status', 'Sub_Category Serial', ['class' => 'my-2']); ?>

<?php echo Form::select('status', [1 => 'Active', 0 => 'Inactive'], null, [
    'class' => 'form-control ',
    'placeholder' => 'Enter Sub_Category status',
]); ?>

<?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/modules/sub_category/form.blade.php ENDPATH**/ ?>