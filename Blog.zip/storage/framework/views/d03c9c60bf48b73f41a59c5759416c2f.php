<div class="main-banner header-text">
    <div class="container-fluid">
        <div class="owl-banner owl-carousel">
            <?php $__currentLoopData = $banner_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <img src="<?php echo e(url('image/post/Original/'.$banner_post->photo)); ?>" alt="<?php echo e($banner_post->title); ?>">
                <div class="item-content">
                    <div class="main-content">
                        <div class="meta-category">
                            <span><?php echo e($banner_post->category?->name); ?></span>
                        </div>
                        <a href="<?php echo e(route('Front.single', $banner_post->slug)); ?>">
                            <h4><?php echo e($banner_post->title); ?></h4>
                        </a>
                        <ul class="post-info">
                            <li><a href="#"><?php echo e($banner_post->user?->name); ?></a></li>
                            <li><a href="#"><?php echo e($banner_post->created_at->format('M d, Y')); ?></a></li>
                            <li><a href="#"><?php echo e($banner_post->comment->count()); ?> Comments</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/frontend/includes/banner.blade.php ENDPATH**/ ?>