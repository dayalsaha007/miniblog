<?php $__env->startSection('page_title', 'Tag'); ?>
<?php $__env->startSection('page_sub_title', 'Create'); ?>
<?php $__env->startSection('contant'); ?>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Create Tag</h4>
                </div>
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php echo Form::open(['method' => 'POST', 'route' => 'tag.store']); ?>

                    <?php echo Form::label('name', 'Name', ['class' => 'my-2']); ?>

                    <?php echo Form::text('name', null, [
                        'id' => 'name',
                        'class' => 'form-control',
                        'placeholder' => 'Enter tag Name',
                    ]); ?>

                    <?php echo Form::label('slug', 'Slug', ['class' => 'my-2']); ?>

                    <?php echo Form::text('slug', null, [
                        'id' => 'slug',
                        'class' => 'form-control ',
                        'placeholder' => 'Enter tag Slug',
                    ]); ?>

                    <?php echo Form::label('order_by', 'tag Serial', ['class' => 'my-2']); ?>

                    <?php echo Form::number('order_by', null, ['class' => 'form-control ', 'placeholder' => 'Select tag Serial']); ?>

                    <?php echo Form::label('status', 'tag Serial', ['class' => 'my-2']); ?>

                    <?php echo Form::select('status', [1 => 'Active', 0 => 'Inactive'], null, [
                        'class' => 'form-control ',
                        'placeholder' => 'Enter tag status',
                    ]); ?>

                    <?php echo Form::button('Create tag', ['type' => 'submit', 'class' => 'btn btn-success mt-3']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            $('#name').on('input', function() {
                let name = $(this).val()
                let slug = name.replaceAll(' ', '-')
                $('#slug').val(slug.toLowerCase());
            })
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/modules/tag/create.blade.php ENDPATH**/ ?>