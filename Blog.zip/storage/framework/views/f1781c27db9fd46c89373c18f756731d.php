<?php $__env->startSection('page_title', 'Sub Category'); ?>
<?php $__env->startSection('page_sub_title', 'Update'); ?>
<?php $__env->startSection('contant'); ?>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Update Sub Category</h4>
                </div>
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php echo Form::model($subCategory, ['method' => 'PUT', 'route' => ['sub_category.update', $subCategory->id]]); ?>

                    <?php echo $__env->make('Backend.modules.sub_category.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::button('Update Sub_sub_category', ['type' => 'submit', 'class' => 'btn btn-success mt-2']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <a href="<?php echo e(route('sub_category.index')); ?>" class="btn btn-danger text-light"> Back </a>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            $('#name').on('input', function() {
                let name = $(this).val()
                let slug = name.replaceAll(' ', '-')
                $('#slug').val(slug.toLowerCase());
            })
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/modules/sub_category/edit.blade.php ENDPATH**/ ?>