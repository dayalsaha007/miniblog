<?php $__env->startSection('page_title', 'Post'); ?>
<?php $__env->startSection('page_sub_title', 'Details'); ?>
<?php $__env->startSection('contant'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4>Post Details</h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered table-hover">
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <th><?php echo e($post->id); ?></th>
                            </tr>
                            <tr>
                                <th>Title</th>
                                <td><?php echo e($post->title); ?></td>
                            </tr>
                            <tr>
                                <th>Slug</th>
                                <td><?php echo e($post->slug); ?></td>>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e($post->status == 1 ? 'Active' : 'Inactive'); ?></td>
                            </tr>
                            <tr>
                                <th>Is Admin</th>
                                <td><?php echo e($post->is_admin == 1 ? 'published' : 'Not Published'); ?></td>
                            </tr>
                            <tr>
                                <th>Discription</th>
                                <td><?php echo $post->discription; ?></td>
                            </tr>
                            <tr>
                                <th>Admin Comment</th>
                                <td><?php echo $post->admin_comment; ?></td>
                            </tr>
                            <tr>
                                <th>Created At</th>
                                <td><?php echo e($post->created_at->toDayDateTimeString()); ?></td>
                            </tr>
                            <tr>
                                <th>Uploadted At</th>
                                <td><?php echo e($post->created_at != $post->updated_at ? $post->updated_at->toDayDateTimeString() : 'Not Updated'); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>Deleted At</th>
                                <td><?php echo e($post->deleted_at != null ? $post->deleted_at->toDayDateTimeString() : 'Not Deleted'); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>Photo</th>
                              <td><img class="img-thumbnail post-image" data-src="<?php echo e(url('image/post/Original/'.$post->photo)); ?>" src="<?php echo e(url('image/post/Thumbnail/'.$post->photo)); ?>" alt="<?php echo e($post->title); ?>">
                                </td>
                            </tr>
                            <tr>
                                <th>Tags</th>
                                <td>
                                    <?php
                                        $colors = ['btn-danger', 'btn-info', 'btn-dark', 'btn-success', 'btn-warning']
                                    ?>
                                    <?php $__currentLoopData = $post->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('tag.show', $tag->id)); ?>"><button class="btn -btn-sm mb-3 <?php echo e($colors[random_int(0,4)]); ?>"><?php echo e($tag->name); ?></button></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('post.index')); ?>" class="btn btn-info btn-sm text-light"> Back </a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4>Category Details</h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered table-hover">
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($post->category?->id); ?></td>
                            </tr>
                            <tr>
                                <th>Category Name</th>
                                <td><?php echo e($post->category->name); ?></td>
                            </tr>
                            <tr>
                                <th>Category Slug</th>
                                <td><?php echo e($post->category->slug); ?></td>
                            </tr>
                            <tr>
                                <th>Ordder By</th>
                                <td><?php echo e($post->category?->order_by); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e($post->category?->status == 1 ? 'Active' : 'Inactive'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('category.show', $post->category?->id)); ?>" class="btn btn-success">Show Category</a>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">
                    <h4>Sub Category Details</h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered table-hover">
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($post->sub_category?->id); ?></td>
                            </tr>
                            <tr>
                                <th>Category Name</th>
                                <td><?php echo e($post->sub_category->name); ?></td>
                            </tr>
                            <tr>
                                <th>Category Slug</th>
                                <td><?php echo e($post->sub_category->slug); ?></td>
                            </tr>
                            <tr>
                                <th>Ordder By</th>
                                <td><?php echo e($post->sub_category?->order_by); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e($post->sub_category?->status == 1 ? 'Active' : 'Inactive'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('sub_category.show', $post->sub_category->id)); ?>" class="btn btn-success">Show Sub Category</a>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">
                    <h4>User Details</h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered table-hover">
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($post->user?->id); ?></td>
                            </tr>
                            <tr>
                                <th>Category Name</th>
                                <td><?php echo e($post->user?->name); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e($post->user->email); ?></td>
                            </tr>
                            <tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e($post->user?->status == 1 ? 'Active' : 'Inactive'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                 </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Blog-Laravel\MiniBlog\resources\views/Backend/modules/post/show.blade.php ENDPATH**/ ?>